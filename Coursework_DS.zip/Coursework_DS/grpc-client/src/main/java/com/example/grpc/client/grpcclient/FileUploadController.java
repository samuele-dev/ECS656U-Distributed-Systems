package com.example.grpc.client.grpcclient;

import java.io.IOException;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.ArrayList;

import java.io.BufferedReader;
//import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
//import java.util.Arrays;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.grpc.client.grpcclient.storage.StorageFileNotFoundException;
import com.example.grpc.client.grpcclient.storage.StorageService;
import com.example.grpc.client.grpcclient.GRPCClientService;

import com.example.grpc.server.grpcserver.MatrixRequest;
import com.example.grpc.server.grpcserver.MatrixReply;
import com.example.grpc.server.grpcserver.MatrixServiceGrpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

@Controller
public class FileUploadController {
	private final StorageService storageService;
	// Store ports of servers located on the same vm instance
	int[] grpcServerPorts = {
			9051, 9052, 9053, 9054, 9055, 9056, 9057, 9058
	};

	@Autowired
	public FileUploadController(StorageService storageService) {
		this.storageService = storageService;
	}

	@GetMapping("/")
	public String listUploadedFiles(Model model) throws IOException {

		model.addAttribute("files", storageService.loadAll().map(
						path -> MvcUriComponentsBuilder.fromMethodName(FileUploadController.class,
								"serveFile", path.getFileName().toString()).build().toUri().toString())
				.collect(Collectors.toList()));

		return "uploadForm";
	}

	@GetMapping("/files/{filename:.+}")
	@ResponseBody
	public ResponseEntity<Resource> serveFile(@PathVariable String filename) {

		Resource file = storageService.loadAsResource(filename);
		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
				"attachment; filename=\"" + file.getFilename() + "\"").body(file);
	}

	// Calculates the number of rows and columns of the matrix string.
	public static int[] calculateMatrixSize(String path){
		Scanner scan = null;
		String line = "";
		int rows = 0;
		int cols = 0;
		int[] size = new int[2];
		try {
			scan = new Scanner(new BufferedReader(new FileReader(path)));

			while (scan.hasNextLine()){
				line = scan.nextLine();
				String[] array = line.split(" ");
				rows++;
				cols = array.length;
			}
			size [0] = rows;
			size [1] = cols;
			return size;
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return size;
	}
	// Turns the file uploaded by the user into a string format.
	public static String convertInputStreamToString(InputStream input) {
		try {
			if(input != null) {
				BufferedReader reader = new BufferedReader(new InputStreamReader(input));
				StringBuilder sb = new StringBuilder();
				String line;

				while ((line = reader.readLine()) != null) {
					sb.append(line).append("\n");
				}

				return sb.toString();
			}
		}
		catch(IOException ignored) {}

		return "";
	}

	// Converts the string formatted file into a 2D integer array i.e., a matrix.
	public static int[][] convertFileToMatrix(String file){
		// Allows us to read the file. https://www.baeldung.com/java-buffered-reader
		try {
			String[] lines = file.split("\n");
			// Create a 2D array.
			int[][] matrix = new int[lines.length][];

			for(int row = 0; row < lines.length; row++) {
				String[] part = lines[row].split(" ");
				matrix[row] = new int[part.length];

				for(int column = 0; column < lines.length; column++) {
					matrix[row][column] = Integer.parseInt(part[column]);
				}
			}

			return matrix;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	// Prints a 2D matrix
	public static void print2DMatrix(int[][] matrix){
		for (int row = 0; row < matrix.length; row++) {
			for (int col = 0; col < matrix[row].length; col++) {
				System.out.print(matrix[row][col] + " ");
			}
			// Formatting purposes - Each row will have its own line.
			System.out.println();
		}
	}
	// Prints a 2D matrix in an HTML format for end results
	public String html2DMatrix(int[][] matrix){
		StringBuilder result = new StringBuilder();
		for (int row = 0; row < matrix.length; row++) {
			for (int col = 0; col < matrix[row].length; col++) {
				result.append(matrix[row][col]).append(" ");
			}

			result.append("<br>");
		}

		return result.toString();
	}

	// Checks if square matrices dimensions are powers of 2.
	static boolean isPowerOfTwo(int n){
		if (n == 0){
			return false;
		}
		while (n != 1){
			if (n % 2 != 0){
				return false;
			}
			n = n / 2;
		}
		return true;
	}

	// Runs a demo request by opening a channel, making the request, and shutting it down when it finishes.
	// Depending on how long your matrix request and response took to complete, that is your footprint.
	public void runFootprint(int[][] matrix1, int[][] matrix2) {
		int server = new Random().nextInt(grpcServerPorts.length);

		// Start a channel with a random server based on the port.
		// Open the connection
		ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", grpcServerPorts[server])
				.usePlaintext()
				.build();

		// Setting up the stub (Used to set up different values you want to send to the server)
		MatrixServiceGrpc.MatrixServiceBlockingStub stub = MatrixServiceGrpc.newBlockingStub(channel);
		MatrixReply A=stub.addBlock(MatrixRequest.newBuilder()
				.setA00(matrix1[0][0])
				.setA01(matrix1[0][1])
				.setA10(matrix1[1][0])
				.setA11(matrix1[1][1])
				.setB00(matrix2[0][0])
				.setB01(matrix2[0][1])
				.setB10(matrix2[1][0])
				.setB11(matrix2[1][1])
				.build());

		// Close this channel.
		channel.shutdown();
	}
	// Matrix addition - Pass the first and second matrix including the total number of servers required.
	public int[][] addMatrices(int[][] firstMatrix, int[][] secondMatrix, int totalChannelToUse) {
		// Used to keep track of which server needs to be used next.
		int channelToUse = 0;
		// We create a new 2D array storing our results. The size shall be of the same dimension of the first & second matrix.
		int[][] result = new int[firstMatrix.length][firstMatrix[0].length];

		ManagedChannel[] channels = new ManagedChannel[totalChannelToUse];
		MatrixServiceGrpc.MatrixServiceBlockingStub[] stubs = new MatrixServiceGrpc.MatrixServiceBlockingStub[totalChannelToUse];


		// Opening all GRPC Channels and the matrix stubs needed.
		for(int i = 0; i < totalChannelToUse; i++) {
			channels[i] = ManagedChannelBuilder.forAddress("localhost", grpcServerPorts[i])
					.usePlaintext()
					.build();

			// Set up the request - matrix stub
			stubs[i] = MatrixServiceGrpc.newBlockingStub(channels[i]);
		}

		int y = 0; // rows
		int x; // columns

		while(y < firstMatrix.length) {
			x = 0;

			while(x < firstMatrix.length) {
				// set up 2x2 blocks
				int[][] a = new int[2][2];
				a[0][0] = firstMatrix[y][x];
				a[0][1] = firstMatrix[y][x+1];
				a[1][0] = firstMatrix[y+1][x];
				a[1][1] = firstMatrix[y+1][x+1];

				int[][] b = new int[2][2];
				b[0][0] = secondMatrix[y][x];
				b[0][1] = secondMatrix[y][x+1];
				b[1][0] = secondMatrix[y+1][x];
				b[1][1] = secondMatrix[y+1][x+1];

				// seting up the addblock based on 2x2 blocks
				MatrixReply answer = stubs[channelToUse].addBlock(MatrixRequest.newBuilder()
						.setA00(a[0][0]).setA01(a[0][1]).setA10(a[1][0]).setA11(a[1][1])
						.setB00(b[0][0]).setB01(b[0][1]).setB10(b[1][0]).setB11(b[1][1])
						.build());

				// store the results.
				result[y][x] = answer.getC00();
				result[y][x+1] = answer.getC01();
				result[y+1][x] = answer.getC10();
				result[y+1][x+1] = answer.getC11();

				// How many channels are left that can take the job in the meantime.
				// If we have reached the maximum number of channels, reset back to the first channel.
				if(channelToUse >= totalChannelToUse-1) {
					channelToUse = -1;
				}

				channelToUse = channelToUse+1;
				x = x+2;
			}

			y = y+2;
		}

		// close or shutdown the channels.
		for(int i = 0; i < channelToUse; i++) {
			channels[i].shutdown();
		}

		return result;
	}

	public int[][] multiplyMatrices(int[][] firstMatrix, int[][] secondMatrix, int totalChannelToUse) {
		// Used to keep track which server to use next.
		int channelToUse = 0;
		int[][] result = new int[firstMatrix.length][firstMatrix[0].length];

		ManagedChannel[] channels = new ManagedChannel[totalChannelToUse];
		MatrixServiceGrpc.MatrixServiceBlockingStub[] stubs = new MatrixServiceGrpc.MatrixServiceBlockingStub[totalChannelToUse];

		// Opening all GRPC Channels and the matrix stubs needed.
		for(int i = 0; i < totalChannelToUse; i++) {
			channels[i] = ManagedChannelBuilder.forAddress("localhost", grpcServerPorts[i])
					.usePlaintext()
					.build();

			// Set up the request - matrix stub
			stubs[i] = MatrixServiceGrpc.newBlockingStub(channels[i]);
		}

		int y = 0; // rows
		int x; // columns
		int z;

		while(y < firstMatrix.length) {
			x = 0;

			while(x < firstMatrix[0].length) {
				z = 0;

				while(z < firstMatrix.length) {
					// set up 2x2 blocks
					int[][] a = new int[2][2];
					a[0][0] = firstMatrix[y][z];
					a[0][1] = firstMatrix[y][z + 1];
					a[1][0] = firstMatrix[y + 1][z];
					a[1][1] = firstMatrix[y + 1][z + 1];

					int[][] b = new int[2][2];
					b[0][0] = secondMatrix[z][x];
					b[0][1] = secondMatrix[z][x + 1];
					b[1][0] = secondMatrix[z + 1][x];
					b[1][1] = secondMatrix[z + 1][x + 1];

					// seting up the addblock based on 2x2 blocks
					MatrixReply answer = stubs[channelToUse].multiplyBlock(MatrixRequest.newBuilder()
							.setA00(a[0][0]).setA01(a[0][1]).setA10(a[1][0]).setA11(a[1][1])
							.setB00(b[0][0]).setB01(b[0][1]).setB10(b[1][0]).setB11(b[1][1])
							.build());

					// store the results.
					result[y][x] = result[y][x] + answer.getC00();
					result[y][x + 1] = result[y][x + 1] + answer.getC01();
					result[y + 1][x] = result[y + 1][x] + answer.getC10();
					result[y + 1][x + 1] = result[y + 1][x + 1] + answer.getC11();

					// How many channels are left that can take the job in the meantime.
					// If we have reached the maximum number of channels, reset back to the first channel.
					if (channelToUse >= totalChannelToUse - 1) {
						channelToUse = -1;
					}

					channelToUse = channelToUse + 1;
					z = z+2;
				}

				x = x+2;
			}

			y = y+2;
		}

		// close or shutdown the channels.
		for(int i = 0; i < channelToUse; i++) {
			channels[i].shutdown();
		}

		return result;
	}

	@PostMapping("/")
	public String handleFileUpload(@RequestParam("file1") MultipartFile file1,
								   @RequestParam("file2") MultipartFile file2,
								   @RequestParam("deadline") int deadline,
								   @RequestParam("operation") String operation,
								   RedirectAttributes redirectAttributes) throws IOException {

		// Check if the file is not empty
		if(file1 == null || file1.isEmpty()) {
            redirectAttributes.addFlashAttribute("message", "File 1 is empty.");
            return "redirect:/";
		}
		if(file2 == null || file2.isEmpty()) {
			redirectAttributes.addFlashAttribute("message", "File 2 is empty.");
			return "redirect:/";
		}
		// Store the file.
		storageService.store(file1);
		storageService.store(file2);
		// Convert files into strings
		String file1String =  convertInputStreamToString(file1.getInputStream());
		String file2String =  convertInputStreamToString(file2.getInputStream());

		// Check if string is empty
		if (file1String.equals("")){
			redirectAttributes.addFlashAttribute("message", "File 1 is empty.");
			return "redirect:/";
		}
		if (file2String.equals("")){
			redirectAttributes.addFlashAttribute("message", "File 2 is empty.");
			return "redirect:/";
		}
		// Turn string into matrices
		int[][] firstMatrix = convertFileToMatrix(file1String);
		int[][] secondMatrix = convertFileToMatrix(file2String);

		if(firstMatrix == null) {
			redirectAttributes.addFlashAttribute("message", "There was an issue reading the matrix of file 1.");
			return "redirect:/";
		}

		if(secondMatrix == null) {
			redirectAttributes.addFlashAttribute("message", "There was an issue reading the matrix of file 2.");
			return "redirect:/";
		}

		// Check for power of 2
		int matrix1Rows = firstMatrix.length;
		int matrix1Columns = firstMatrix[0].length;

		if (isPowerOfTwo(matrix1Rows) == false || isPowerOfTwo(matrix1Columns) == false){
			redirectAttributes.addFlashAttribute("message", "Matrix 1 is not to the power of 2.");
			return "redirect:/";
		}

		int matrix2Rows = secondMatrix.length;
		int matrix2Columns = secondMatrix[0].length;

		if (isPowerOfTwo(matrix2Rows) == false || isPowerOfTwo(matrix2Columns) == false){
			redirectAttributes.addFlashAttribute("message", "Matrix 2 is not to the power of 2.");
			return "redirect:/";
		}
		// Check if they are square matrices
		if (matrix1Rows != matrix1Columns){
			redirectAttributes.addFlashAttribute("message", "Matrix 1 is not a square matrix.");
			return "redirect:/";
		}
		if (matrix2Rows != matrix2Columns){
			redirectAttributes.addFlashAttribute("message", "Matrix 2 is not a square matrix.");
			return "redirect:/";
		}
		// Check if both matrices are equal
		if(matrix1Rows != matrix2Rows){
			redirectAttributes.addFlashAttribute("message", "Both matrix rows are not the same size.");
			return "redirect:/";
		}
		// Calculate how many servers are required for the given process.
		long startTime = System.nanoTime();
		long footprint;
		// The footprint is the total amount of time a process took to complete its objective.
		runFootprint(firstMatrix, secondMatrix);
		footprint = (System.nanoTime()-startTime)/1000000000;
		// Calculates the number of servers required to complete the calculation within the given deadline.
		int totalServersToUse = (int) (((matrix1Columns * matrix2Columns * footprint) / deadline)+1);

		System.out.println("Footprint: " + footprint);
		System.out.println("Total Servers To Use: " + totalServersToUse);
		/*
			If the calculated number of servers (recommendation) is greater than the amount of servers we have,
		 	throw an error to inform the user that the computation cannot take place.
		 */
		if(totalServersToUse > grpcServerPorts.length) {
			redirectAttributes.addFlashAttribute("message", "Exceeded the capacity of servers for calculating the matrices.");
			return "redirect:/";
		}

		// This is where we will store the results
		int[][] result = new int[2][2];
		// Depending on what the user selected in the drop-down list, the following mathematical operation will take place.
		if(operation.equals("add")) {
			result = addMatrices(firstMatrix, secondMatrix, totalServersToUse);
		} else if(operation.equals("multiply")) {
			result = multiplyMatrices(firstMatrix, secondMatrix, totalServersToUse);
		}

		// Show success message on html page along with the result.
		redirectAttributes.addFlashAttribute("message", "The calculation was complete");
		redirectAttributes.addFlashAttribute("result", html2DMatrix(result));

		return "redirect:/";
	}

	@ExceptionHandler(StorageFileNotFoundException.class)
	public ResponseEntity<?> handleStorageFileNotFound(StorageFileNotFoundException exc) {
		return ResponseEntity.notFound().build();
	}
}